# -*- coding: utf-8 -*-
"""
Created on Fri Sep 21 12:52:51 2018

@author: benoi
"""

__version__ = '0.1'
